# MediMap — Setup Guide

## 1. Install dependencies
```bash
npm install
```

## 2. Set up Supabase

1. Create a project at https://supabase.com
2. Go to SQL Editor → paste and run `supabase-schema.sql`
3. Go to Storage → create a bucket named `reports` (set to **private**)
4. Go to Project Settings → API → copy your URL and anon key

## 3. Set up Gemini API

1. Go to https://aistudio.google.com/app/apikey
2. Create an API key (free tier — 15 requests/min is enough for a hackathon)

## 4. Configure environment variables

```bash
cp .env.local.example .env.local
```

Fill in `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=url
NEXT_PUBLIC_SUPABASE_ANON_KEY=kry
SUPABASE_SERVICE_ROLE_KEY=ey
NEXTAUTH_SECRET=run: openssl rand -base64 32
GEMINI_API_KEY=GEMINI_API_KEY=YOUR_GEMINI_API_KEY
```

## 5. Run the app
```bash
npm run dev
```

Open http://localhost:3000

---

## File Structure

```
src/
  app/
    page.tsx                    ← Landing page
    login/page.tsx              ← Sign in
    register/page.tsx           ← Sign up
    onboarding/page.tsx         ← 3-step onboarding
    dashboard/page.tsx          ← Post-login home
    upload/page.tsx             ← Upload + Gemini extraction
    reports/
      page.tsx                  ← Reports vault
      [id]/page.tsx             ← Per-report analysis
    health-overview/
      page.tsx                  ← Trends + recommended tests + doctors
      HealthCharts.tsx          ← Recharts client component
    profile/
      page.tsx                  ← Profile page
      ProfileEditForm.tsx       ← Editable form client component
    api/
      upload/route.ts           ← PDF upload + Gemini OCR
      reports/route.ts          ← CRUD for reports/values
      auth/register/route.ts    ← Registration endpoint
  components/
    layout/Sidebar.tsx          ← Shared sidebar
  lib/
    gemini.ts                   ← Gemini AI utilities
    supabase/client.ts          ← Browser Supabase client
    supabase/server.ts          ← Server Supabase client
  types/index.ts                ← TypeScript types
supabase-schema.sql             ← Run this in Supabase SQL Editor
```

## Flow

1. User registers → redirected to `/onboarding`
2. Onboarding saves profile + conditions to Supabase
3. User uploads PDF at `/upload` → goes to `/api/upload`
4. API uploads file to Supabase Storage, calls Gemini, saves extracted values
5. User reviews/edits values → saves → redirected to `/reports/[id]`
6. Report analysis page shows AI summary, abnormal flags, parameters table
7. `/health-overview` shows trends across reports + recommended tests
