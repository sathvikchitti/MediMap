import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient, createAdminSupabaseClient } from '@/lib/supabase/server'

// GET /api/reports — fetch all reports for logged-in user
export async function GET(request: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const reportId = searchParams.get('id')

  if (reportId) {
    // Get single report with its values
    const { data: report, error } = await supabase
      .from('reports')
      .select('*, report_values(*)')
      .eq('id', reportId)
      .eq('user_id', user.id)
      .single()

    if (error) return NextResponse.json({ error: error.message }, { status: 404 })
    return NextResponse.json({ report })
  }

  // Get all reports
  const { data: reports, error } = await supabase
    .from('reports')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ reports })
}

// PATCH /api/reports — update report values (user edits extracted values)
export async function PATCH(request: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { report_id, values } = await request.json()

  const adminSupabase = createAdminSupabaseClient()

  // Upsert each value
  for (const v of values) {
    if (v.id) {
      // Update existing
      await adminSupabase
        .from('report_values')
        .update({
          parameter_name: v.parameter_name,
          value: v.value,
          unit: v.unit,
          ref_range_text: v.ref_range_text,
          status: v.status,
          updated_at: new Date().toISOString(),
        })
        .eq('id', v.id)
        .eq('user_id', user.id)
    } else {
      // Insert new value added by user
      await adminSupabase
        .from('report_values')
        .insert({
          report_id,
          user_id: user.id,
          parameter_name: v.parameter_name,
          value: v.value,
          unit: v.unit,
          ref_range_text: v.ref_range_text,
          status: v.status || 'Normal',
        })
    }
  }

  return NextResponse.json({ success: true })
}

// DELETE /api/reports
export async function DELETE(request: NextRequest) {
  const supabase = createServerSupabaseClient()
  const { data: { user }, error: authError } = await supabase.auth.getUser()

  if (authError || !user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const reportId = searchParams.get('id')

  if (!reportId) return NextResponse.json({ error: 'Report ID required' }, { status: 400 })

  const adminSupabase = createAdminSupabaseClient()

  // Delete values first (cascade should handle this but being explicit)
  await adminSupabase.from('report_values').delete().eq('report_id', reportId).eq('user_id', user.id)

  const { error } = await adminSupabase
    .from('reports')
    .delete()
    .eq('id', reportId)
    .eq('user_id', user.id)

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ success: true })
}
