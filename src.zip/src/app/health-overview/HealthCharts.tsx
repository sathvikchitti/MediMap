'use client'

import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts'

interface TrendData {
  date: string
  value: number
  unit: string
}

export default function HealthCharts({
  trendableParams,
}: {
  trendableParams: [string, TrendData[]][]
}) {
  const colors = ['#1A1A2E', '#C4793A', '#2D6A4F', '#B5382A']

  return (
    <div className="grid grid-cols-2 gap-4">
      {trendableParams.map(([param, data], i) => {
        const latest = data[data.length - 1]
        const prev = data[data.length - 2]
        const change = prev ? (((latest.value - prev.value) / prev.value) * 100).toFixed(1) : null
        const trending = change ? (parseFloat(change) > 0 ? `↑ +${change}%` : `↓ ${change}%`) : null
        const trendColor = change ? (parseFloat(change) > 0 ? '#B5382A' : '#2D6A4F') : '#6B6B6B'

        const chartData = data.map(d => ({
          date: new Date(d.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
          value: d.value,
        }))

        return (
          <div key={param} className="card">
            <div className="flex items-start justify-between mb-2">
              <p className="font-playfair font-bold text-primary text-sm">{param}</p>
              <div className="text-right">
                <p className="font-playfair text-xl font-bold text-primary">{latest.value}</p>
                <p className="text-xs text-muted">{latest.unit}</p>
              </div>
            </div>

            <ResponsiveContainer width="100%" height={100}>
              <LineChart data={chartData}>
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#6B6B6B' }} axisLine={false} tickLine={false} />
                <YAxis hide domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ background: '#fff', border: '1px solid #E8E4DC', borderRadius: 4, fontSize: 12 }}
                  labelStyle={{ color: '#1A1A2E', fontWeight: 600 }}
                />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke={colors[i % colors.length]}
                  strokeWidth={2}
                  dot={{ fill: colors[i % colors.length], r: 3 }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>

            {trending && (
              <p className="text-xs mt-1" style={{ color: trendColor }}>
                {trending} from last test
              </p>
            )}
          </div>
        )
      })}
    </div>
  )
}
