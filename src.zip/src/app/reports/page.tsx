import { createServerSupabaseClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import Sidebar from '@/components/layout/Sidebar'

export default async function ReportsPage() {
  const supabase = createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: profile } = await supabase.from('profiles').select('full_name').eq('id', user.id).single()
  const { data: reports } = await supabase
    .from('reports')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar userName={profile?.full_name || undefined} />
      <main className="ml-60 flex-1 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-playfair text-3xl font-bold text-primary">My Reports</h1>
            <p className="text-muted text-sm mt-1">All your uploaded medical records in one place.</p>
          </div>
          <Link href="/upload" className="btn-primary">+ Upload New Report</Link>
        </div>

        {!reports || reports.length === 0 ? (
          <div className="card text-center py-16">
            <p className="text-muted mb-4">No reports uploaded yet.</p>
            <Link href="/upload" className="btn-primary">Upload Your First Report</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {reports.map(report => (
              <div key={report.id} className="card flex items-center gap-4 hover:border-accent/50 transition-colors">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
                  <span className="text-accent text-xs font-bold">{report.report_type?.substring(0, 3).toUpperCase() || 'RPT'}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-primary">{report.report_name}</p>
                  <p className="text-xs text-muted truncate">
                    {report.lab_name || 'Unknown lab'} · {report.test_date ? new Date(report.test_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : 'Date unknown'}
                  </p>
                  {report.report_type && (
                    <span className="text-xs border border-border text-muted px-2 py-0.5 rounded-full mt-1 inline-block">{report.report_type}</span>
                  )}
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className={report.abnormal_count > 0 ? 'status-high' : 'status-normal'}>
                    {report.abnormal_count > 0 ? `${report.abnormal_count} Abnormal` : 'All Normal'}
                  </span>
                  <Link href={`/reports/${report.id}`} className="text-sm text-accent hover:underline font-medium">
                    View Analysis →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
